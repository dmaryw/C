#include<stdio.h>
int i,j,k,a;

int main(){
	printf("Enter the number of rows :");
       	scanf("%d",&a);
	for(i=1;i<=a;i++){
		for(j=1;j<=a-i;j++){
			printf(" ");
		}
		int c=1;
		for(k=1;k<=i;k++){
			printf("%d",c);
			c = c * (i - k) / k;
		}
		printf("\n");
	}
	return 0;
}
