#include<stdio.h>
int main(){
	int i,j,n=6;
	char ch ='A',c=ch+n;;
	for(i = 0;i<=n;i++){
		for(j=-n;j<=n;j++){
			if(j>-i &&j<i)
				printf(" ");
			else{
				if(j>0)
					printf("%c",c-j);
				else
					printf("%c",c+j);
			}
		}
		printf("\n");
	}
}

