#include<stdio.h>
int i,j,row;
int main(){
	printf("Enter the number of rows : ");
	scanf("%d",&row);
	
	for(i=0;i<=row;i++){
		for(j=1;j<=i;j++){
			printf("%d",j);
		}
		printf("\n");
	}
	return 0;
}
