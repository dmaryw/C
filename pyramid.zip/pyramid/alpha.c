#include<stdio.h>
int i,j;
char row,alpha ='A';

int main(){
	printf("Enter an input character you want to print in the row :");
	scanf("%c",&row);
	for(i=1;i<=(row-'A'+1);i++){
		for(j=1;j<=i;j++){
			printf("%c",alpha);
		}
		++alpha;
		printf("\n");}
}
