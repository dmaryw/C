#include<stdio.h>
int i,a,j;
int main(){
	printf("The pyramid is going to be printed\n");
	for(i=0;i<=5;i++){
		for(j=1;j<=i;j++){
			printf("* ");
		}
			printf("\n");
	}	
	return 0;
}
