#include<stdio.h>
int i,j,a;

int main()
{
	printf("enter the Number of rows :");
	scanf("%d",&a);
	for(i=1;i<=a;i++){
		for(j=1;j<=a;j++){
			printf("*");
		}
		printf("\n");
	}
}
