#include<stdio.h>
int main() {
	int i,n=5,j,m;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			m=i+j+1;
			if(m>5){
				m=m-5;
				printf("%d ",m); 
			}
			else
				printf("%d ",m);
		}
		printf("\n");
	}
}

