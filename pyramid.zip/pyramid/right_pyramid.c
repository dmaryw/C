#include<stdio.h>
int i,a,j,k;
int main(){
	printf("Enter the number of rows :");
	scanf("%d",&a);
	for(i=1;i<=a;i++){
		for(j=1;j<=a-i;j++){
			printf(" ");
		}
			for(k=1;k<=i;k++)
			{
				printf("*");
			}
	printf("\n");
	}

	return 0;
}
