//hollow leftside tilt triangle
/*#include<stdio.h>
int i,j,n;
int main(){
	printf("Enter the number ");
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		for(j=1;j<=i;j++){
			if((i==1)||(i==n)||(i==j)||(j==1)){
				printf("*");
			}
			else
				printf(" ");
		}
		printf("\n");
	}
}
*/

//Hollow rightside tilt triangle

#include<stdio.h>
int i,j,k,n;
int main(){
	printf("Enter the number");
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		for(j=1;j<=n-i;j++){
			printf("  ");
		}
		for(k=1;k<=i;k++){
			if((k==1)||(k==i)||(i==n))
			//printf("* ");

			printf("%d ",i);
			else
				printf("  ");
		}
		printf("\n");
	}
}
