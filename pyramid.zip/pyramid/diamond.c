#include<stdio.h>
int i,j,l,s,n=3;
int main(){
	for(i=-n;i<=n;i++){
		char ch = 'A';
		if(i<0)
			l=-i;
		else
			l=i;
		for(s=0;s<l;s++)
			printf("  ");
		for(j=0;j<2*(n-l)+1;j++){
			if(j%2 == 0){
				printf("%c ",ch);
				ch =ch+2;
			}
			else
				printf("* ");
		}
			printf("\n");
	
	}
}
