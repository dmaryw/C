// Floyd's triangle is one in which all the natural numbers are printed in pyrmid format
//
#include<stdio.h>
int i,j,cnt=0,row;
int main(){
	printf("Enter the number of rows :");
	scanf("%d",&row);

	for(i=0;i<=row;i++){
		for(j=1;j<=i;j++){
			cnt++;
			printf("%d ",cnt);
		}
		printf("\n");
	}
	return 0;
}
