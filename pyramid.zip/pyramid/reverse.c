#include<stdio.h>
int i,j,row;
int main(){
	printf("Enter the number of rows :");
	scanf("%d",&row);

	for(i=row;i>=1;i--)
	{
		for(j=1;j<=i;j++){
			//printf("*");
			printf("%d",j);
		}
		printf("\n");
	}
	return 0;
}

