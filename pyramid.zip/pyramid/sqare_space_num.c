#include<stdio.h>
int main(){
	int i,j,n=4,m = n;
	for(i=n;i>=0;i--){
		for(j=-n;j<=n;j++){
			if(j>-i && j<i)
				printf(" ");
			else
				if(j>0)
					printf("%d",m-j+1);
				else
					printf("%d",m+j+1);
		}
	printf("\n");
	}
}
