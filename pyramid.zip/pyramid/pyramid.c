#include<stdio.h>
int i,j,k,row,row1;
 int main(){
	 printf("Enter the number of rows :");
	 scanf("%d",&row);
	 row=row1;
	 for(i=1;i<=row*2;i=i+2){
		 for(j=row;j>=0;j--)
		 {
			 printf(" ");
		 }

	 }
	 return 0;
 }
