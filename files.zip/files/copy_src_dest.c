#include<stdio.h>
int main(int argc,char *argv[]){
	FILE *fs = fopen(argv[1],"r");
	if(fs == NULL)
		printf("The file does not exist\n");
	else
		printf("The file exists \n");
	char ch;
	int i;
	FILE *fd;
	for(i=2;i<argc;i++){
		fd = fopen(argv[i],"w");

		while((ch = fgetc(fs))!=EOF){
			printf("%c",ch);
			fputc(ch,fd);
		}
		fclose(fd);
		rewind(fs);
	}
	fclose(fs);
}

