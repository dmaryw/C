#include<stdio.h>
int main(){
	FILE *fp = fopen("data.txt","r");
	if(fp == NULL)
		printf("The file does not exist\n");
	else
		printf("The file exists\n");
	char ch;
	while((ch = fgetc(fp))!=EOF)
		printf(" %c",ch);
}
