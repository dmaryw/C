
// Online C compiler to run C program online
#include <stdio.h>

int main(int argc,char *argv[]) {
	FILE*fs = fopen(argv[1],"r");
	if(fs == NULL){
		printf("The does not exist\n");
		return 0;
	}
	char ch;
	int i;
	for(i=2;i<argc;i++){
		FILE*fp = fopen(argv[i],"w");
		while((ch =fgetc(fs))!=EOF)
			fputc(ch,fp);
		fclose(fp);
		fclose(fs);
	}
	int c = remove(argv[1]);
	if(c==0)
		printf("The file is removed successfully");
}
