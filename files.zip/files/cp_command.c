#include<stdio.h>
int main(){
	FILE *fp1 = fopen("data.txt","r");
	FILE *fp2 = fopen("new.txt","w");
	if(fp1 == NULL)
		printf("The file does not exist\n");
	else
		printf("The file exists\n");
	char ch;
	while((ch = fgetc(fp1))!=EOF){
		printf("%c",ch);
		fputc(ch,fp2);
	}
	fclose(fp2);
	fclose(fp1);
}
