// Online C compiler to run C program online
#include <stdio.h>

int main(int argc,char *argv[]) {
   FILE*fp = fopen(argv[1],"r");
    if(fp==NULL){
        printf("File doesnot exist");
        return 0;
    }
    char ch,a[20];
    int word= 0,lines =0,character =0;
    while(fscanf(fp,"%s",a)!=EOF)
    ++word;
    rewind(fp);
    while((ch = fgetc(fp))!=EOF){
      ++character;
      if(ch=='\n')
      ++lines;
}
printf("%d %d %d %s",lines,character,word,argv[1]);
fclose(fp);
}
