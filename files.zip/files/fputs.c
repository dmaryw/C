#include<stdio.h>
int main(){
	FILE *fp = fopen("data.txt","r");
	if(fp == NULL)
		printf("File does not exist\n");
	return 0;
	 cha ch;
	 FILE *fd = fopen("f1.txt","w");
	 while(fgets(ch,5,fp)!=0)
		 fputs(ch,fd);
}
