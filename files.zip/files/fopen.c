#include<stdio.h>
int main(){
	FILE *fp = fopen("data.txt","r");
	if(fp == NULL)
		printf("The file does not exist");
	else
		printf("The file exists");
}
