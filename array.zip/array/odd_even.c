#include<stdio.h>
int a[]={1,2,3,4,5,6,7,8,9},b[10],c[10],i,n=sizeof a/sizeof a[0],cnt1=0,cnt2=0;
int main(){
	for(i=0;i<n;i++){
		if(a[i] % 2==0){
			cnt1++;
			b[i]=a[i];
			printf("Even array  %d\n",b[i]);
		}
	}
			printf("Even count %d\n",cnt1);
	for(i=0;i<n;i++){
		if(a[i] % 2!=0){
			cnt2++;
			c[i]=a[i];
			printf("Odd array %d\n",c[i]);
		}
	}
			printf("odd count %d\n",cnt2);

}
