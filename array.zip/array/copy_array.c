#include<stdio.h>
int a[]={1,2,3,4,5},n=sizeof a/sizeof a[0],i,b[10];
int main(){
	for(i=0;i<n;i++){
		b[i]=a[i];

	//for(i=0;i<n;i++)
		printf("%d",b[i]);
	}
}
