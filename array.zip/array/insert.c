#include<stdio.h>
int a[20],i,s,p,ne;//ne-new element
int main(){
	printf("Enter the size of the array\n");
	scanf("%d",&s);
	for(i=0;i<s;i++){
		printf("Enter the element : ");
		scanf("%d",&a[i]);
	}
	printf("Enter the new element\n");
	scanf("%d",&ne);
	for(p=0;p<s;p++){
		if(a[p]>ne)
			break;
	}
	for(i=s;i>p;i--){
		a[i]=a[i-1];
	}
	a[p]=ne;
	s++;
	for(i=0;i<s;i++){
		printf("The new array is %d\n",a[i]);
	}
}
