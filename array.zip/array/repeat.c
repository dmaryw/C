#include<stdio.h>
int i,a[]={1,2,2,4,3,4,2,6,2,7,2,8,2,9,2,0,2},n,b,cnt;
int main(){
	n = sizeof a / sizeof a[0];
	for(i=0;i<n;i++)
		printf("%d",a[i]);
	printf("\n");
	printf("Enter the elments that needs to be searched ");
	scanf("%d",&b);
	for(i=0;i<n;i++){
		if(b == a[i])
			cnt++;
	}
	printf("%d",cnt);
	printf("\n");
}

