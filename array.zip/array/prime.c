#include<stdio.h>
int   a[10]={1,2,3,4,5,6,7,8,9,10},n=sizeof a/sizeof a[0],cnt,i,j,c=0;
int main(){
	for(i=1;i<n;i++){
		cnt=0;
		for(j=2;j<=i;j++){
			if(a[i] % j == 0){
				cnt++;
				break;
			}
		}
		if(cnt==0){
			printf("The prime nums are %d\n",a[i]);
			c++;
		}
	}
		printf("The number of primes available is %d\n",c);
}
