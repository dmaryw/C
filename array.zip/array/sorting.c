//Bubble sort
#include<stdio.h>
int a[10]={5,3,1,6,4,7,0,9,2,8},in,out,n,tmp;

int main(){
	n=sizeof(a)/sizeof (int);
	for(out=0;out<=n-1;out++){
		for(in=out+1;in<n;in++){
			if(a[out]>a[in]){
				tmp=a[out];
				a[out]=a[in];
				a[in]=tmp;
			}
		}
	}
	for(out=0;out<n;out++)
		printf("%d",a[out]);
}
