#include<stdio.h>
int a[]={1,2,3,4,5,7,8,9,10},i,j,tmp,n=sizeof a/sizeof a[0];
int main(){
        for(i=0;i<n/2;i++){
                j=n-1-i;
                        tmp = a[i];
                        a[i] = a[j];
                        a[j] = tmp;

        }
        for(i=0;i<n;i++){
                printf("%d",a[i]);
        }
}

