#include<stdio.h>
int i,j,a[5];
int main(){
	for(i=0;i<5;i++){
		printf("Enter the element: ");
		scanf("%d",&a[i]);
	}
	for(i=4;i>=0;i--){
		printf("The elements are %d",a[i]);
		printf("\n");
		//i++;
	}
}
