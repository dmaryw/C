#include<stdio.h>
int a[10],i,b[10];
int main(){
	for(i=0;i<3;i++){
		printf("Enter the elements : ");
		scanf("%d",&a[i]);
	}
	for(i=0;i<3;i++){
		printf("%d",a[i]);
	}
	printf("\n");
	for(i=0;i<3;i++)
	b[i]=a[i];
	for(i=0;i<3;i++){
		printf("%d",b[i]);
	}
	}
