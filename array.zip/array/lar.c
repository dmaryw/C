#include<stdio.h>
int a[10]={6,3,4,2,1,7,8,30},i,j;

int main(){
	int greatest=a[0];
	for(i=0;i<=10;i++){
		if(a[i]>greatest){
			greatest =a[i];
		}
	}
	printf("The greatest number is %d",greatest);
}

