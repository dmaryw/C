#include<stdio.h>
int a[]={10,20,30,40,50,40,30,20,10},i,j,n;
int main(){
        n = sizeof a / sizeof a[0];
        for(i=0;i<n;i++)
                printf("%d ",a[i]);
        for(i=0;i<n;i++){
                for(j=n-1-i;j>=0;j--){
                        if(a[i] != a[j]){
                                printf("Not Palindrome");
                                return 0;
                        }
                        if(i>=j){
                                printf("Plaindrome");
                                return 0;
                        }
                        break;
                }
        }

}

