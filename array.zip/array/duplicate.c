#include<stdio.h>
int a[10],o,i,cnt=0;

int main(){
	for(i=0;i<6;i++){
		printf("Enter the elements :");
		scanf("%d",&a[i]);
	}
	
	   for(i=0;i<6;i++){
		   cnt=0;
	   for(o=0;o<6;o++){
	   if(a[i]==a[o]){
	   cnt++;
	   }
	   }
	   
	   if(cnt==1)
		   printf("%d ",a[i]);
	   }
	   
}
