#include<stdio.h>
int a[20],i,p,ne,s,j,tmp;
int main(){
	printf("Enter the size of array");
	scanf("%d",&s);
	for(i=0;i<s;i++){
		printf("Enter Elements : ");
		scanf("%d",&a[i]);
	}
	for(i=0;i<s;i++){
		for(j=i+1;j<s;j++){
			if(a[i]>a[j]){
				tmp=a[j];
				a[j]=a[i];
				a[i]=tmp;
			}
		}
			printf("The sorted elements are : %d\n",a[i]);
	}
	printf("Enter the new element : \n");
	scanf("%d",&ne);
	for(p=0;p<s;p++){
		if(a[p]>ne)
			break;
	}

	for(i=s;i>p;i--){
		a[i]=a[i-1];
	}
	a[p]=ne;
	s++;
	for(i=0;i<s;i++){
		printf("The sorted array with new inserted element is :%d \n",a[i]);
	}
}
