#include<stdio.h>
int a[10]={2,4,1,0,5,3,21},min,max,i,j;
int main(){
	max=a[0];
	min=a[0];
	for(i=0;i<10;i++){
		for(j=1;j<10;j++){
			if(a[i]>max)
				max=a[i];
			if(a[i]<max)
				min=a[i];
		}
	}
	printf("The minimum value is %d\n The maximum valuse is %d\n",min,max);
}

