#include<stdio.h>
int i,a[3],sum;

int main(){
	for(i=0;i<3;i++){
		printf("Enter the value : ");
		scanf("%d",&a[i]);
	}
	for(i=0;i<3;i++){
		printf("%d ",a[i]);
	}
	for(i=0;i<3;i++){
		sum =sum+a[i];
	}
	printf("\n%d\n",sum);
}
