#include<stdio.h>
int a[10]={1,1,2,2,3,4,5,6,7,4},i,j,n=sizeof a/sizeof a[0],cnt;
int main(){
	for(i=0;i<n;i++)
		printf("%d ",a[i]);
	printf("\n");
	for(i=0;i<n;i++){
		cnt=1;
		for(j=0;j<i;j++){
			if(a[i]==a[j])
				break;
		}
		if(i!=j)
			continue;
		for(j=i+1;j<n;j++){
			if(a[i]==a[j])
				cnt++;
		}
		if(cnt==1)
			printf("%d is non-duplicate\n",a[i]);
	}
}
