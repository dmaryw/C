#include<stdio.h>
int i,a[3];

int main(){
	for(i=0;i<3;i++){
		printf("Enter the value : ");
		scanf("%d",&a[i]);
	}
	for(i=2;i>=0;i--){
		printf("%d",a[i]);
	}
}
