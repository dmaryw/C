#include<stdio.h>
int a[10],i;

int main(){
	for(i=0;i<10;i++){
		printf("Enter the %d element : ",i);
		scanf("%d",&a[i]);
	}
	for(i=0;i<10;i++){
		printf("%d",a[i]);
	}
		printf("\n");
}
