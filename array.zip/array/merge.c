#include<stdio.h>
int a[100],b[100],c[100],s1,s2,s3,i,j,k,tmp;

int main(){
	printf("Enter the size of s1, s2 : \n");
	scanf("%d %d",&s1,&s2);
	for(i=0;i<s1;i++){
		printf("Enter the elements in the array 1 : ");
		scanf("%d",&a[i]);
	}
	for(i=0;i<s2;i++){
		printf("Enter the elements in the array 2 : ");
		scanf("%d",&b[i]);
	}
	for(i=0;i<s1;i++){
		c[i]=a[i];
	}
	for(j=0;j<s2;j++){
		c[i+j]=b[j];
	}
	s3=s1+s2;
	printf("Size of s3 is %d\n",s3);
	for(i=0;i<s3;i++){
		printf("Print the elements in the array 3 are: %d",c[i]);
		printf("\n");
	}
	for(i=0;i<s3;i++){
		for(j=i+1;j<s3;j++){
		//	if(c[i]<c[j]){
			if(c[i]>c[j]){
				tmp=c[i];
				c[i]=c[j];
				c[j]=tmp;
			}
		}
	}
	for(i=0;i<s3;i++){
	//	printf("Print the elements in the array 3  after arranged in descending order : %d",c[i]);
		printf("Print the elements in the array 3  after arranged in ascending order : %d",c[i]);
		printf("\n");
	}


}
