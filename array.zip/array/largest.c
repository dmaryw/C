#include<stdio.h>
int a[5]={1,2,8,4,5},n=sizeof a/sizeof a[0],b,i,j;
int main(){
	b=a[0];
	for(i=0;i<n-1;i++){
			if(a[i]>b)
				b=a[i];
	}
		printf("%d",b);
}

