#include<stdio.h>
int a[6]={1,2,3,4,5},pos,i,n=5;
int main(){
	printf("Enter the position ");
	scanf("%d",&pos);
	if((pos<0)||(pos>n-1)){
		printf("invalid index\n");
		return 0;
	}
	for(i=n;i>pos;i--){
		a[i]=a[i-1];
	}
	a[pos]=9;
	n++;
	for(i=0;i<n;i++){
		printf("%d",a[i]);
	}
}

