#include<stdio.h>
int row,col,i,j;

int main(){
	printf("Enter the number of rows :\n");
	scanf("%d",&row);
	printf("Enter the number of column : \n");
	scanf("%d",&col);
	int arr[row][col];
	printf("Enter the elements");

	for(i=0;i<row;++i){
	       for(j=0;j<col;++j){
	       printf("Elements are [%d][%d]\n",i,j);
	       scanf("%d",&arr[i][j]);
	       }
	}

	for(i=0;i<row;++i){
		for(j=0;j<col;++j){
			printf("%d",arr[i][j]);
		}
	}
	printf("\n");
	return 0;
}


