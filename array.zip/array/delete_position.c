#include<stdio.h>
int a[5]={1,2,3,4,5},pos,i,n=sizeof a/ sizeof a[0];
int main(){
	printf("Enter the position ");
	scanf("%d",&pos);
	for(i=pos;i<n-1;i++){
		a[i]=a[i+1];
	}
	n--;
	for(i=0;i<n;i++){
		printf("%d",a[i]);
	}
}

