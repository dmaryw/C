#include<stdio.h>
int i;
char a[20],b[20];
int main(){
	printf("enter the string:\n");
	scanf(" %[^\n]",a);
	for(i=0;a[i];i++){
		b[i]=a[i];
	}
	b[i]='\0';
	printf("%s",b);
}
