#include<stdio.h>
#include<string.h>
int i,j,a=0;
char s[20],tmp;
int main(){
	printf("Enter the string : ");
	scanf(" %[^\n]",s);
	a=strlen(s);
	printf("%d\n",a);
	for(i=0;i<a/2;i++){
		tmp=s[i];
		s[i]=s[a-1-i];
		s[a-1-i]=tmp;
	}
	printf("%s",s);
}
