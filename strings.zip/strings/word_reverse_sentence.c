#include<stdio.h>
#include<string.h>
int main(){
	char s[20];
	int i,j,n = 0;
	printf("Enter the string :\n");
	scanf(" %[^\n]",s);
	n=strlen(s);
	for(i=0;i<s[i];i++){
		if(s[i]!=' ' && s[i]!='\0')
			i++;
		else
			for(j = i-1;j>=0;j--)
			

	}
}
