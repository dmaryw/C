#include<stdio.h>
int i,j;
char a[20],b[20];
int main(){
	printf("Enter the string :\n");
	scanf(" %[^\n]",a);
	for(i=0;a[i];i++){
		if (a[i] == ' '){
			for(j=i;a[j];j++){
				a[j]=a[j+1];
			}
			i--;
		}
	}
	printf("%s",a);
}
