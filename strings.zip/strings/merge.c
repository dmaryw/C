#include<stdio.h>
int main(){
	char a[20],b[20],c[20];
	int i,j,k;
	printf("Enter string 1:\n");
	scanf(" %[^\n]",a);
	printf("Enter string 1:\n");
	scanf(" %[^\n]",b);
	while(a[i]!='\0' ||b[j]!='\0'){
		if(a[i]!='\0'){
			c[k++]=a[i++];
		}
		if(b[j]!='\0'){
			c[k++]=b[j++];
		}
	}
	c[k]='\0';

	printf("%s\n",c);
}


