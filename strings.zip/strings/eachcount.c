#include<stdio.h>
#include<string.h>
char a[20],c;
int i,n,cnt=0,j;
int main(){
	printf("Enter the string :\n");
	scanf(" %[^\n]",a);
	for(i=0;a[i];i++){
		cnt=1;
		for(j=i;j<=i;j++){
			if (a[i] == a[j])
				break;
		}
		if(i!=j)
			continue;
		for(j=i+1;j<a[i];j++){
			if (a[i]==a[j])
				cnt++;
		}
		printf("The count of %c is %d\n",a[i],cnt); 
	}
}
