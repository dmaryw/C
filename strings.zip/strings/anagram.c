#include<stdio.h>
#include<string.h>
int main(){
	char a[] = {"1a2#&il  @Ste  0$ N4"};
	char b[] = {"LS^90  !eni*t"};
	int len1,len2,i,j;
	char tmp;
	for(i=0;a[i];i++){
		if(!((a[i]>='A'&& a[i]<= 'Z')||(a[i]>='a'&& a[i]<= 'z'))){
			for(j=i;a[j];j++)
				a[j]=a[j+1];
			i--;
		}
	}
	printf("%s\n",a);
	for(i=0;b[i];i++){
		if(!((b[i]>='A'&& b[i]<= 'Z')||(b[i]>='a'&& b[i]<= 'z'))){
			for(j=i;b[j];j++)
				b[j]=b[j+1];
			i--;
		}
	}
	printf("%s\n",b);



	len1 = strlen(a);
	len2 = strlen(b);
	printf("%d\n",len1);
	printf("%d\n",len2);


	if(len1 != len2){
		printf("The strings are not equal and they cannot be an anagram\n");
	}
	for(i=0;a[i];i++){
		if(a[i]>='a'&& a[i]<='z'){
			a[i] = a[i]^32;
		}
	}
	for(i=0;b[i];i++){
		if(b[i]>='a'&& b[i]<='z'){
			b[i] = b[i]^32;
		}
	}
	printf("After case conversion : %s\n",a);
	printf("After case conversion : %s\n",b);
	for(i=0;i<len1-1;i++){
		for(j=i+1;j<len1;j++){
			if (a[i]>a[j]){
				tmp=a[i];
				a[i] =a[j];
				a[j]=tmp;
			}
		}
	}
	printf("After sorting\n");
	printf("%s\n",a);
	for(i=0;i<len2-1;i++){
                for(j=i+1;j<len2;j++){
                        if (b[i]>b[j]){
                                tmp=b[i];
                                b[i] =b[j];
                                b[j]=tmp;
                        }
                }
        }
        printf("%s\n",b);
	int result = strcmp(a,b);
	if(result == 0)
		printf(" The strings are in Anagram format\n ");
	else
		printf("Not in anagram format \n");
}

