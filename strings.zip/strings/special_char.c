#include<stdio.h>
int i;
char a[20],cnt=0;
int main(){
	printf("Enter the string :\n");
	scanf(" %[^\n]",a);
	for(i=0;a[i];i++){
		if(!((a[i]>='A' && a[i]<='Z') || (a[i]>='a' && a[i]<='z') || (a[i]>='0' && a[i]<='9'))){
			cnt++;
		}
	}
	printf("%d\n",cnt);
}

