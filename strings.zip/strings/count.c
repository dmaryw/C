#include<stdio.h>
#include<string.h>
char a[20],c;
int i,n,cnt;
int main(){
	printf("Enter the string :\n");
	scanf(" %[^\n]",a);
	printf("Enter the character that needs to be searched :\n");
	scanf(" %c",&c);
	n=strlen(a);
	for(i=0;i<n;i++){
		if (a[i] == c)
			cnt++;
	}
	if(a[i]!=c)
		printf("The entered character is not present in the entered string\n");
	printf("The count is : %d\n",cnt); 
}
